# NOVA·SX — GitHub Actions APK Build
### Build your Android synth APK entirely from your phone via GitHub

---

## Steps (all done on your phone, no computer needed)

### 1. Create a GitHub account
Go to https://github.com and sign up for a free account.

### 2. Create a new repository
- Tap the **+** icon → **New repository**
- Name it: `novasynth`
- Set to **Public** (required for free Actions minutes)
- Tick **"Add a README file"**
- Tap **Create repository**

### 3. Upload the project files
You need to upload ALL files from this zip into the repository,
keeping the folder structure exactly as-is.

The easiest way on mobile:
- In your new repo, tap **"uploading an existing file"** (on the repo main page)
- Upload files one folder at a time, or use the GitHub mobile app

**Critical: the folder structure must match exactly:**
```
novasynth/
├── .github/
│   └── workflows/
│       └── build.yml          ← The Actions workflow
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/
│       │   └── synth.html
│       ├── java/com/novasx/synth/
│       │   └── MainActivity.java
│       └── res/
│           ├── mipmap-*/      ← All icon folders
│           ├── values/
│           │   ├── strings.xml
│           │   └── themes.xml
│           └── xml/
│               └── device_filter.xml
├── build.gradle
├── gradle.properties
├── gradle/wrapper/
│   └── gradle-wrapper.properties
└── settings.gradle
```

**TIP:** Use the GitHub mobile app (free on Play Store) — it lets you upload
an entire zip and extract it into the repo automatically.

### 4. Trigger the build
- Go to your repo → tap the **Actions** tab
- You'll see "Build NovaSynth APK" workflow
- Tap **Run workflow** → **Run workflow** (green button)
- Wait ~5 minutes for the build to complete ✓

The workflow also runs automatically every time you push/upload files.

### 5. Download your APK
- In the Actions tab, tap the completed workflow run
- Scroll down to **Artifacts**
- Tap **NovaSynth-APK** → it downloads as a zip
- Unzip it → tap `app-debug.apk` to install

### 6. Install on your phone
- Tap the APK file in your Downloads
- Android will ask to allow installing from unknown sources
- Go to Settings → allow → come back and install
- NOVA·SX appears on your home screen!

---

## Why this works better than Replit
- GitHub's build servers have Android SDK pre-configured
- Free for public repos (2,000 minutes/month)
- APK stays available for 30 days to re-download
- Re-trigger the build any time from your phone

---

## Troubleshooting

**Build fails with "SDK not found"**
→ The `android-actions/setup-android` step handles this automatically.
  Check the Actions log for the exact error.

**"Gradle wrapper not found"**
→ The workflow generates it automatically — no gradle-wrapper.jar needed.

**APK installs but no sound**
→ Tap the screen once after opening — Android requires a user gesture
  to start Web Audio.

**MIDI not detected**
→ Connect keyboard before opening the app, or close and reopen.
  The status bar shows connection state.
