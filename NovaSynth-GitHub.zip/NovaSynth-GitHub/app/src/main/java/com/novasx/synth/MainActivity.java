package com.novasx.synth;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiManager;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiReceiver;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;

public class MainActivity extends Activity {

    private WebView webView;
    private MidiManager midiManager;
    private MidiDevice openDevice;
    private MidiOutputPort outputPort;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on while playing
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Full screen immersive
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        webView = new WebView(this);
        setContentView(webView);

        // WebView settings
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        // Allow audio autoplay and MIDI
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // Auto-grant audio capture and MIDI
                request.grant(request.getResources());
            }
        });

        webView.setWebViewClient(new WebViewClient());

        // Inject native MIDI bridge into JS
        webView.addJavascriptInterface(new MidiBridge(), "AndroidMidiBridge");

        // Load synth from assets
        webView.loadUrl("file:///android_asset/synth.html");

        // Init Android MIDI manager
        initMidi();
    }

    // ── MIDI BRIDGE ─────────────────────────────────────────────────────────
    // This JS interface lets the HTML page check if native MIDI is available.
    // The real MIDI messages are injected directly into JS from the Java side.
    public class MidiBridge {
        @JavascriptInterface
        public String getStatus() {
            return openDevice != null ? "connected" : "disconnected";
        }
    }

    private void initMidi() {
        midiManager = (MidiManager) getSystemService(Context.MIDI_SERVICE);
        if (midiManager == null) {
            notifyWebView("MIDI SERVICE NOT AVAILABLE ON THIS DEVICE");
            return;
        }

        scanAndConnect();

        // Listen for new devices being plugged in
        midiManager.registerDeviceCallback(new MidiManager.DeviceCallback() {
            @Override
            public void onDeviceAdded(MidiDeviceInfo device) {
                if (openDevice == null) scanAndConnect();
            }
            @Override
            public void onDeviceRemoved(MidiDeviceInfo device) {
                closeCurrentDevice();
                notifyWebView("MIDI DEVICE DISCONNECTED");
            }
        }, mainHandler);
    }

    private void scanAndConnect() {
        MidiDeviceInfo[] devices = midiManager.getDevices();
        if (devices == null || devices.length == 0) {
            notifyWebView("NO MIDI DEVICES FOUND — CONNECT KEYBOARD");
            return;
        }
        // Pick first device with output ports (keyboard sends output to us)
        for (MidiDeviceInfo info : devices) {
            if (info.getOutputPortCount() > 0) {
                connectDevice(info);
                return;
            }
        }
        notifyWebView("MIDI DEVICE FOUND BUT NO OUTPUT PORTS");
    }

    private void connectDevice(MidiDeviceInfo info) {
        midiManager.openDevice(info, device -> {
            if (device == null) {
                notifyWebView("FAILED TO OPEN MIDI DEVICE");
                return;
            }
            openDevice = device;
            outputPort = device.openOutputPort(0);
            if (outputPort == null) {
                notifyWebView("FAILED TO OPEN MIDI OUTPUT PORT");
                return;
            }
            outputPort.connect(new MidiReceiver() {
                @Override
                public void onSend(byte[] msg, int offset, int count, long timestamp) {
                    handleMidiBytes(msg, offset, count);
                }
            });
            String name = info.getProperties()
                .getString(MidiDeviceInfo.PROPERTY_NAME, "UNKNOWN DEVICE");
            notifyWebView("✓ CONNECTED: " + name.toUpperCase());
        }, mainHandler);
    }

    private void handleMidiBytes(byte[] msg, int offset, int count) {
        if (count < 2) return;
        int status  = msg[offset]     & 0xFF;
        int data1   = count > 1 ? (msg[offset+1] & 0xFF) : 0;
        int data2   = count > 2 ? (msg[offset+2] & 0xFF) : 0;

        // Build the JS call — mirror exactly what WebMIDI would send
        final String js = String.format(
            "javascript:(function(){ " +
            "  if(typeof onMIDIMessage === 'function'){ " +
            "    onMIDIMessage({data:[%d,%d,%d]}); " +
            "  } " +
            "})()", status, data1, data2);

        mainHandler.post(() -> webView.loadUrl(js));
    }

    private void notifyWebView(String msg) {
        final String safeMsg = msg.replace("'", "\\'");
        mainHandler.post(() -> webView.loadUrl(
            "javascript:(function(){ " +
            "  if(typeof setMidiStatus === 'function'){ " +
            "    setMidiStatus('" + safeMsg + "', '" +
            (msg.startsWith("✓") ? "connected" : "error") + "'); " +
            "    if('" + (msg.startsWith("✓") ? "y" : "n") + "' === 'y'){ " +
            "      var l = document.getElementById('led-midi'); " +
            "      if(l) l.classList.add('on'); " +
            "    } " +
            "  } " +
            "})()"
        ));
    }

    private void closeCurrentDevice() {
        if (outputPort != null) {
            try { outputPort.close(); } catch (IOException e) { /* ignore */ }
            outputPort = null;
        }
        if (openDevice != null) {
            try { openDevice.close(); } catch (IOException e) { /* ignore */ }
            openDevice = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-hide system UI if user swiped it back
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeCurrentDevice();
        if (webView != null) webView.destroy();
    }
}
